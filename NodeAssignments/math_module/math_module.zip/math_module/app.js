var math = require('./mathlib');
var mathlib = math();
mathlib.add(2, 4);
mathlib.multiply(2, 8);
mathlib.square(2);
mathlib.random(5, 12);